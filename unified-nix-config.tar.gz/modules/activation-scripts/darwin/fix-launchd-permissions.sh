# Fix LaunchDaemon permissions
/bin/sh /run/current-system/sw/etc/fix-nix-mount-plist.sh